package com.example.finalapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.appcompat.widget.Toolbar;

import com.example.finalapp.SuggestionPage.SuggestionFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawerLayout;
    NavigationView drawerNav;
    Toolbar tbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        ------------------------Drawer Navigation---------------
        drawerLayout = findViewById(R.id.drawer_layout);
        drawerNav = findViewById(R.id.draw_nav_view);
        tbar = findViewById(R.id.toolbar);

        setSupportActionBar(tbar);

        drawerNav.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, tbar, R.string.nav_open, R.string.nav_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        drawerNav.setNavigationItemSelectedListener(this);

        drawerNav.setCheckedItem(R.id.draw_home);


//        --------------------Bottom Navigation View------------
        BottomNavigationView navigationView = findViewById(R.id.btm_Nav);
        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                int id = menuItem.getItemId();

                if (id == R.id.Home) {
                    HomeFragment fragment = new HomeFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.Frame_Layout, fragment);
                    fragmentTransaction.commit();
                    drawerNav.setCheckedItem(R.id.draw_home);
                }

                if (id == R.id.Suggestion) {

                    SuggestionFragment fragment = new SuggestionFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.Frame_Layout, fragment);
                    fragmentTransaction.commit();
                }

                if (id == R.id.Inquires) {

                    InquiresFragment fragment = new InquiresFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.Frame_Layout, fragment);
                    fragmentTransaction.commit();
                }

                if (id == R.id.Profile) {

                    ProfileFragment fragment = new ProfileFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.Frame_Layout, fragment);
                    fragmentTransaction.commit();
                }

                return true;
            }
        });

        navigationView.setSelectedItemId(R.id.Home);
    }

    @Override
    public void onBackPressed() {

        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        BottomNavigationView navigationView = findViewById(R.id.btm_Nav);

        switch (item.getItemId()){
            case R.id.draw_home:
                navigationView.setSelectedItemId(R.id.Home);
                HomeFragment hf = new HomeFragment();
                FragmentTransaction hft = getSupportFragmentManager().beginTransaction();
                hft.replace(R.id.Frame_Layout, hf);
                hft.commit();
                break;
        }

        drawerLayout.closeDrawer(GravityCompat.START);

        return true;
    }
}
