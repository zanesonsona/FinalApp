package com.example.finalapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class RegistrationPage extends AppCompatActivity implements View.OnClickListener {

    Button signupButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_page);

        signupButton = (Button) findViewById(R.id.signup);

        signupButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if (v==signupButton){
            Intent intent = new Intent(this,LoginPage.class);
            startActivity(intent);
        }

    }
}
