package com.example.finalapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LoginPage extends AppCompatActivity implements View.OnClickListener {

    Button loginButton;
    TextView  register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        loginButton = (Button) findViewById(R.id.login);
        register = (TextView) findViewById(R.id.signup);

        register.setOnClickListener(this);
        loginButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        if (v==register){
            Intent intent = new Intent(this, RegistrationPage.class);
            startActivity(intent);
        }

        if (v==loginButton){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }

    }
}
